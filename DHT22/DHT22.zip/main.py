import dht
from machine import Pin
import utime

# Initialize DHT22 on GP4
sensor = dht.DHT22(Pin(4))

while True:
        sensor.measure()  # Read sensor data
        temp = sensor.temperature()
        hum = sensor.humidity()
        
        print(f"Temperature: {temp}°C, Humidity: {hum}%")
    
        utime.sleep(2)  # Wait before next reading
