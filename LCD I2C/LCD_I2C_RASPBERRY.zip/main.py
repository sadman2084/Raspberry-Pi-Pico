from machine import Pin, I2C
from time import sleep
from pico_i2c_lcd import I2cLcd

i2c = I2C(0, sda=Pin(4), scl=Pin(5), freq=400000)#can make the data transfer more efficient
lcd = I2cLcd(i2c, i2c.scan()[0], 2, 16)

while True:
    lcd.putstr("Hello Sadman")
    sleep(5)
    lcd.clear()
