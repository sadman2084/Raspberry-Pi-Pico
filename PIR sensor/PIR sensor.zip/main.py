from machine import Pin
import time

led = Pin(19, Pin.OUT)
pir = Pin(28, Pin.IN, Pin.PULL_UP)

while True:
    if pir.value() == 1:
        led.value(1)  # Turn on LED
        time.sleep(3)
    else:
        led.value(0)  # Turn off LED
    time.sleep(2)
